<!DOCTYPE html>
<html>
<head>
	<title>Welcome to DevOps on AWS</title>
</head>
<body>
	<h1><?php echo "Welcome to DevOps on AWS. This text was generated using PHP 7" ?></h1>
	<h2><?php echo "This change will be reflected using Ansible pull" ?></h2>
</body>
</html>